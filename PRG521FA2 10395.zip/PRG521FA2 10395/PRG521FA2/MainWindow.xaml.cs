﻿using System.Windows;



namespace PRG521FA2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();


        }



        //Button for Barcode page
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Barcode objbarwindow = new Barcode();
            this.Visibility = Visibility.Hidden;
            objbarwindow.Show();
        }



        //Button for AddProducts page
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddProducts objaddwindow = new AddProducts();
            this.Visibility = Visibility.Hidden;
            objaddwindow.Show();
        }


        //Button for List_Product page
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            List_Product objlistwindow = new List_Product();
            this.Visibility = Visibility.Hidden;
            objlistwindow.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Barcode objbarwindow = new Barcode();
            this.Visibility = Visibility.Hidden;
            objbarwindow.Show();
        }
    }
}


