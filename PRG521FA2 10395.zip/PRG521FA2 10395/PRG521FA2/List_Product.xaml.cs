﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace PRG521FA2
{
    /// <summary>
    /// Interaction logic for List_Product.xaml
    /// </summary>
    public partial class List_Product : Window
    {
        SqlConnection sql;
        public List_Product()
        {
            InitializeComponent();
            filldataGrid();
            SqlConnection sql = new SqlConnection(@"Data Source=.;Initial Catalog=StockSystemdb1;Integrated Security=True");
        }


        public void filldataGrid()
        {
            try
            {

                string command = "SELECT * FROM PRODUCTS";
                SqlCommand sqlCommand = new SqlCommand(command, sql);
                sqlCommand.ExecuteNonQuery();
                SqlDataAdapter dataAdapt = new SqlDataAdapter(sqlCommand);
                DataTable dt = new DataTable("Products");
                dataAdapt.Fill(dt);
                dataGrid1.ItemsSource = dt.DefaultView;
                dataAdapt.Update(dt);

                sql.Close();
            }

            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }




        //button for Main page
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow objmainwindow = new MainWindow();
            this.Visibility = Visibility.Hidden;
            objmainwindow.Show();
        }


    }
}
