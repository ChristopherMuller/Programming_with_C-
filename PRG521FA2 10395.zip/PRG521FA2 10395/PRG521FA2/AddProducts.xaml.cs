﻿using System.Data.SqlClient;
using System.Windows;

namespace PRG521FA2
{
    /// <summary>
    /// Interaction logic for AddProducts.xaml
    /// </summary>
    public partial class AddProducts : Window
    {
        SqlConnection sql;
        public AddProducts()
        {
            InitializeComponent();
            SqlConnection sql = new SqlConnection(@"Data Source=.;Initial Catalog=StockSystemdb1;Integrated Security=True");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            sql.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Products(ProductCategory,ProductName,CostPrice,SellingPrice,Quantity,BarCode)VALUES(@ProductC,@ProductN,@CostP,@SellingP,@qty,@BC)", sql);
            cmd.Parameters.AddWithValue("ProductC", textBox1.Text);
            cmd.Parameters.AddWithValue("ProductN", textBox2.Text);
            cmd.Parameters.AddWithValue("CostP", int.Parse(textBox3.Text));
            cmd.Parameters.AddWithValue("SellingP", int.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("qty", int.Parse(textBox5.Text));
            cmd.Parameters.AddWithValue("BC", int.Parse(textBox6.Text));
            cmd.ExecuteNonQuery();

            sql.Close();
            MessageBox.Show("Product added successfully!");

            MainWindow main = new MainWindow();
            this.Hide();
            main.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow objmainwindow = new MainWindow();
            this.Visibility = Visibility.Hidden;
            objmainwindow.Show();
        }




        //button for Main page
        //private void Button_Click1(object sender, RoutedEventArgs e)
        //{
        //    MainWindow objmainwindow = new MainWindow();
        //   this.Visibility = Visibility.Hidden;
        //   objmainwindow.Show();
        //}


    }
}
